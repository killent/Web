ToDo-ionic
==========

基于ionic framework/angularjs/cordova的ToDo管理应用

需要安装以下Plugin
```bash
cordova plugin add org.apache.cordova.console
cordova plugin add org.apache.cordova.statusbar
cordova plugin add org.apache.cordova.device
cordova plugin add org.apache.cordova.splashscreen
cordova plugin add https://github.com/VitaliiBlagodir/cordova-plugin-datepicker.git
```
运行效果图：
参考[here](http://rensanning.iteye.com/blog/2072034)
